import numpy as np
import matplotlib.pyplot as plt
import os
# import
projectPath = "/Users/maximeglomot/Cours/L3_2020/Vibra/tp1_PoutreEL/CgtPos"
ylsoft = np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_l_soft", "PowerSpectrum.txt") , skiprows=1)
yl = np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_l", "PowerSpectrum.txt") , skiprows=1)
yl2 = np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_lo2", "PowerSpectrum.txt") , skiprows=1)
yl3= np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_lo3", "PowerSpectrum.txt") , skiprows=1)
y2l3 = np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_2lo3", "PowerSpectrum.txt") , skiprows=1)
yl4 = np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_lo4", "PowerSpectrum.txt") , skiprows=1)
y3l4 = np.loadtxt(os.path.join(projectPath,"CgtPos_l_any_3lo4", "PowerSpectrum.txt") , skiprows=1)

fig, ax = plt.subplots(figsize=(30,15))
#ax.semilogy(yl[:,0],yl[:,1],label="Excité en $l$")
#ax.semilogy(yl2[:,0],yl2[:,1],label="Excité en $l/2$")
ax.semilogy(yl3[:,0],yl3[:,1],label="Excité en $l/3$")
#ax.semilogy(yl4[:,0],yl4[:,1],label="Excité en $l/4$")
ax.semilogy(y2l3[:,0],y2l3[:,1],label="Excité en $2l/3$")
ax.semilogy(y3l4[:,0],y3l4[:,1],label="Excité en $3l/4$")

ax.grid()
ax.set_xlim(160,180)
ax.legend()
