import os
from matplotlib import cm
from scipy.interpolate import interp2d
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
projectPath = '/Users/MaximeGlomot/Python/UnivMesures'

donnees_experimentales = ['5_5', '10_5', '15_5', '5_10', '10_10', '15_10',
                          '5_15', '10_15', '15_15', '5_20', '10_20', '15_20', '5_25', '10_25', '15_25']

D = 2.38
rho = 7.057
a = 20
b = 30
m = [1, 2, 3]
n = [1, 2, 3]
Amn = 1
resolution = 100
x1 = np.linspace(0, 20, resolution)
y1 = np.linspace(0, 30, resolution)
X, Y = np.meshgrid(x1, y1)

amp_alg = []
freqRecherche = 90
for each in donnees_experimentales:
    mesure = np.loadtxt(os.path.join(projectPath, '{}.txt'.format(each)))
    frequence = mesure[:, 0]
    freqIndex = np.where(frequence >= freqRecherche)[0][0]
    amplitude = mesure[freqIndex, 1]
    phi = mesure[freqIndex, 2]
    phi = (phi + np.pi) % (2 * np.pi) - np.pi

plotData = np.zeros([7, 5])
i = 0
for (arrayIndex, data) in np.ndenumerate(plotData):
    x, y = arrayIndex
    if not((x in [0, 6]) or (y in [0, 4])):
        plotData[x, y]
        i += 1

measuresCoordinates = np.array([['0_0', '5_0', '10_0', '15_0', '20_0'],
                                ['0_5', '5_5', '10_5', '15_5', '20_5'],
                                ['0_10', '5_10', '10_10', '15_10', '20_10'],
                                ['0_15', '5_15', '10_15', '15_15', '20_15'],
                                ['0_20', '5_20', '10_20', '15_20', '20_20'],
                                ['0_25', '5_25', '10_25', '15_25', '20_25'],
                                ['0_30', '5_30', '10_30', '15_30', '20_30']])

measuresDict = {}

for (arrayIndex, coordinates) in np.ndenumerate(measuresCoordinates):
    measureFilePath = os.path.join(projectPath, '{}.txt'.format(coordinates))
    if os.path.exists(measureFilePath):  # Si le fichier existe
        measuresDict['{}'.format(coordinates)] = np.loadtxt(measureFilePath)
    else:
        measuresDict['{}'.format(coordinates)] = np.loadtxt(
            os.path.join(projectPath, 'valeursLimite.txt'))

def getMeasureData(freq=None):
    freq = freq - 10
    measureData = np.zeros([7, 5])
    measurePhase = np.zeros([7, 5])
    for (arrayIndex, coordinates) in np.ndenumerate(measuresCoordinates):
        x, y = coordinates.split('_')
        x, y = int(x), int(y)
        measureData[arrayIndex] = measuresDict[coordinates][freq][1]
        measurePhase[arrayIndex] = measuresDict[coordinates][freq][2]
    return measureData, measurePhase

x1 = np.arange(0, 21, 5)
y1 = np.arange(0, 31, 5)
X1 = np.linspace(0, 20, np.size(x1) * 10)
Y1 = np.linspace(0, 30, np.size(x1) * 10)
xmesh, ymesh = np.meshgrid(x1, y1)
Xmesh, Ymesh = np.meshgrid(X1, Y1)

lowResData = plotData

f = interp2d(x1, y1, lowResData, kind='cubic')
HDdata = f(X1, Y1)

# MODE 1 1

lowResData, lowResDataPhase = getMeasureData(90)
amp_alg = lowResData * np.exp(lowResDataPhase * 1j)

f = interp2d(x1, y1, amp_alg.real, kind='cubic')
HDdata = f(X1, Y1)

# THEORIE 2D

fig2D = plt.figure(figsize=(15, 5))

Wmn = Amn * (np.sin((1 * np.pi * X) / a)) * (np.sin((1 * np.pi * Y) / b))

ax2D1 = fig2D.add_subplot(121)
mode1 = ax2D1.pcolormesh(X, Y, Wmn, cmap=cm.PuOr)
cbar = plt.colorbar(mode1, shrink=0.8, aspect=5)
cbar.set_label(r"Amplitude")
plt.title('Mode (1,1) $f_{théorique}$ = 93 Hz')
plt.xlabel(r"Position selon $\vec{x}$(en cm)")
plt.ylabel(r"Position selon $\vec{y}$(en cm)")

# EXPERIENCE 2D

ax2D2 = fig2D.add_subplot(122)
plt.title('Mode (1,1) $f_{exp}$= 90 Hz')
f = interp2d(x1, y1, amp_alg.real, kind='cubic')
HDdata = f(X1, Y1)
modeexp1 = ax2D2.pcolormesh(Xmesh, Ymesh, HDdata, cmap=cm.PuOr)
cbar = plt.colorbar(modeexp1, shrink=0.8, aspect=5)
cbar.set_label(r'Amplitude en ${m.s^{-2}/N}$')
plt.xlabel(r"Position selon $\vec{x}$(en cm)")
plt.ylabel(r"Position selon $\vec{y}$(en cm)")
plt.tight_layout()
plt.show()

fig3D = plt.figure(figsize=(15, 5))

# THEORIE 3D

ax3D1 = fig3D.add_subplot(121, projection='3d')
ax3D1.set_zlim(-1.5, 1.5)
mode1 = ax3D1.plot_surface(X, Y, Wmn, cmap=cm.PuOr)
fig3D.colorbar(mode1, shrink=0.5, aspect=5)
plt.xlabel(r"Position selon $\vec{x}$(en cm)")
plt.ylabel(r"Position selon $\vec{y}$(en cm)")
plt.xlim(20, 0)
plt.ylim(0, 30)

# EXPERIENCE 3D

ax3D2 = fig3D.add_subplot(122, projection='3d')
pressureField3D = ax3D2.plot_surface(Xmesh, Ymesh, HDdata, cmap=cm.PuOr)https://www.overleaf.com/project/5a7f57b90703d15be2e2e269
fig3D.colorbar(pressureField3D, shrink=0.5, aspect=5)
ax3D2.view_init(elev=40, azim=30)
plt.xlabel(r"Position selon $\vec{x}$(en cm)")
plt.ylabel(r"Position selon $\vec{y}$(en cm)")
plt.xlim(20, 0)
plt.ylim(30, 0)
plt.tight_layout()
plt.show()