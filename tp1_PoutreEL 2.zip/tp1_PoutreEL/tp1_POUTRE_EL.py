import os
import numpy as np
import pandas as pd
from nptdms import TdmsFile
import matplotlib.pyplot as plt
import peakutils
import scipy.fftpack as fft
import scipy.signal as sp

projectPath="/Users/maximeglomot/Cours/L3_2020/Vibra/tp1_PoutreEL/CgtPos/"
#dirPath="CgtPos"
#dirPath="Hammer"
dirPath="CgtPos"
a=np.array([[1,2,3],[4,5,6]])
a.shape[1]
os.path.exists("/Users/maximeglomot/Cours/L3_2020/Vibra/tp1_FAKE/CgtPos")
os.listdir(os.path.join(projectPath, dirPath))
FolderList = [f for f in os.listdir(os.path.join(projectPath, dirPath)) if  f[0]!='.' if f.split("_")[0]=="0"]




a=np.loadtxt(os.path.join(projectPath, dirPath,"0_w1_noeud", "TemporalData.txt"),skiprows=1)
time=a[:,0].T #toutes les lignes , seulement la colomne 0
plt.plot(time)
print(time)

def getTemporalData(projectPath , dirPath, measurename=None,multiplot=None,filetype="PowerSpectrum"):
    "get temporal data from CTTM : can import both .tdms and .txt from the directory you specify"
    if measurename is not None:
        #try:
        Nsample = np.loadtxt(os.path.join(projectPath, dirPath, measurename,filetype ,".txt"), skiprows = 1)[:,0].T.shape[0]
        temporalData = np.zeros((2,Nsample)) # time + datas
        temporalData[0,:] = np.loadtxt(os.path.join(projectPath, dirPath, measurename,filetype ,".txt"),skiprows = 1)[:,0].T
        temporalData[1,:] = np.loadtxt(os.path.join(projectPath, dirPath, measurename,filetype ,".txt"),skiprows = 1)[:,1].T
        with open(os.path.join(projectPath, dirPath, measurename,filetype ,".txt")) as f:
            line = f.readline()
                    #print(line)
        # except:
        #     tdms_file = TdmsFile(os.path.join(projectPath,dirPath,'Record.tdms'))
        #     temporalData = tdms_file.as_dataframe().to_numpy()
        #     time_track=np.loadtxt(os.path.join(projectPath, "wTx_phase", filetype ,".txt"),skiprows=1)[:,0]
        #     temporalData=np.array([time_track,temporalData[:,0],temporalData[:,1]])
        #     print('\t'.join([f'{i}: '+key.replace("\'", "") for i, key in enumerate(tdms_file.as_dataframe().keys())]))

    if multiplot is not None:
        FolderList = [folder for folder in os.listdir(os.path.join(projectPath, dirPath)) if  folder[0]!='.' if folder.split("_")[0]=="0"]
        Nsample = np.loadtxt(os.path.join(projectPath, dirPath, FolderList[0],filetype ,".txt"), skiprows = 1)[:,0].T.shape[0]
        temporalData=np.zeros(((len(FolderList)+1,Nsample))) # time + datas
        temporalData[0,:]= np.loadtxt(os.path.join(projectPath, dirPath, FolderList[0],filetype ,".txt"), skiprows = 1)[:,0].T

        for i,folder in enumerate(FolderList):
            temporalData[1+i,:] = np.loadtxt(os.path.join(projectPath, dirPath, folder , filetype ,".txt"), skiprows = 1)[:,1].T
            with open(os.path.join(projectPath, dirPath, folder,filetype ,".txt" )) as f:
                line = f.readline()
    return temporalData
                #print(line)
            # if os.path.splitext(file)[-1] == '.tdms':
            #     tdms_file = TdmsFile(os.path.join(projectPath,dirPath,'Record.tdms'))
            #     temporalData = tdms_file.as_dataframe().to_numpy()
            #     time_track=np.loadtxt(os.path.join(projectPath, "wTx_phase", "TemporalData.txt"),skiprows=1)[:,0]
            #     temporalData=np.array([time_track,temporalData[:,0],temporalData[:,1]])
            #     print('\t'.join([f'{i}: '+key.replace("\'", "") for i, key in enumerate(tdms_file.as_dataframe().keys())]))

for i,measures in enumerate(FolderList):
    print(i,measures)
def FFT(data,multiFFT=None):
    spectra=np.zeros_like(data)
    NFFT=spectra.shape[1]
    for i,measures in enumerate(spectra.shape[0]):
        spectra[i]=fft.fft(data[i,:])
    f = np.linspace(0, int(Fs/2), int(N/2))

N=len(spectrum)
f = np.linspace(0, int(Fs/2), int(N/2))
index=peakutils.indexes(spectrum[0:60],min_dist=40)
index
#%%

getTemporalData(projectPath, dirPath, multiplot="Shrubbery")
for measures in range(getTemporalData(projectPath, dirPath, multiplot="Shrubbery").shape[0]-1):
    plt.plot(getTemporalData(projectPath, dirPath, multiplot="Shrubbery")[0,:],getTemporalData(projectPath, dirPath, multiplot="Shrubbery")[measures+1])
plt.show()

a=getTemporalData(projectPath, dirPath, measurename="0_w1_noeud")


#%%



#%%
plt.plot(getTemporalData(projectPath, dirPath, measurename="0_w1_noeud")[0])
fft.fft(getTemporalData(projectPath, dirPath, multiplot="Shrubbery")[1])
#%%
def peakdetectnplot(temporalData , thres1=0.5 , min_dist1=30, thres2=0.5 ,min_dist2=30, maxcue=1, title1= "MyTitle1", title2="Mytitle2",periodlabel1="Période $T_{1}$",periodlabel2="Période $T_{2}$",show=True,savetitle=None, Fs = 10000, tstart = 0, tstop= None,f1=30,f2=88):
    " Use arg: maxcue to plot in red the maxcue and maxcue+1 indexes. In case of 2 DDL, exists peakutils1 and peakutils2. In case of 1 DDL, just take thres1 ,min_dis1."
    timeAxis = temporalData[:,0]
    acc1 = temporalData[:,1]
    if temporalData.shape[1]==3:
        acc2= temporalData[:,2]
    else:
        acc2=None


    nstart= tstart*Fs
    if tstop is None:
        nstop = int(timeAxis[-1]*Fs)
    if tstop is not None:
        nstop = int(tstop*Fs)
    ##### 1 DDL ######

    indexes = peakutils.indexes(acc1[nstart:nstop], thres=thres1, min_dist=min_dist1)

    # Out the coefficient
    T = timeAxis[indexes[maxcue+1]] - timeAxis[indexes[maxcue]]
    # delta = (1/Td)*np.log((acc1[indexes[maxcue]])/(acc1[indexes[maxcue+1]]))
    # omega_0 = np.sqrt((2*np.pi/Td)**2 + delta**2)
    # omega_d = 2*np.pi/Td
    # k = m*omega_0**2
    # c = 2*m/delta
    if acc2 is None:
        plt.figure(figsize=(15,8))
        #plt.title(title1)
        plt.xlabel("Temps en $s$")
        plt.ylabel("Accelération en $V$ ")
        plt.ylim(-acc1[indexes[maxcue]]-0.02,acc1[indexes[maxcue]]+0.02)
        plt.plot(timeAxis[nstart:nstop],acc1[nstart:nstop], label = "Accélération")
        #plt.xlim(nstart,nstop)
        plt.plot(timeAxis[indexes],acc1[indexes],'g+',label = "Maxima locaux")
        plt.plot(timeAxis[indexes[maxcue]],acc1[indexes[maxcue]],'r+', label = "Maxima locaux déterminant la période")
        plt.plot(timeAxis[indexes[maxcue+1]],acc1[indexes[maxcue+1]],'r+',)
        plt.plot( [ timeAxis[indexes[maxcue]] ,timeAxis[indexes[maxcue+1]]],[0,0],'r-', label = " 7 périodes $T_{1}$")
        #plt.plot( [ timeAxis[indexes[maxcue]+int(1/f1/Fs)] ,timeAxis[indexes[maxcue]+int(1/f2/Fs)]],[0,0],'r-', label = " Psoeudo-période $T_2{d}$")
        plt.grid(True)
        plt.legend(loc="best")
        ### SHOW OR SAVE ? ###
        if show==True :
            plt.show()
        if show==False :
            plt.savefig(projectPath + "exports/" + savetitle + ".png")
        return T

    #### 2 DDL #### HERE INDEXES IS A TUPLE OF LISTS, beware!
    if acc2 is not None:
        # peut être changer à
        #        indexes = np.array([peakutils.indexes(acc1[nstart:nstop], thres=thres1, min_dist=min_dist1)],[peakutils.indexes(acc2[nstart:nstop], thres=thres2, min_dist=min_dist2))]

        indexes = (peakutils.indexes(acc1[nstart:nstop], thres=thres1, min_dist=min_dist1),
                   peakutils.indexes(acc2[nstart:nstop], thres=thres2, min_dist=min_dist2))
        T1 = timeAxis[indexes[0][maxcue+1]] - timeAxis[indexes[0][maxcue]]
        T2 = timeAxis[indexes[1][maxcue+1]] - timeAxis[indexes[1][maxcue]]
        plt.figure(figsize=(15,8))

        ### First PLOT ###
        plt.subplot(211)
        # ACC1
        plt.plot(timeAxis[nstart:nstop], acc1[nstart:nstop] , '-', lw=2, label = "$A_{2}$ de l'accéleration" )
        #plt.xlim(nstart,nstop)

        # ALL MAXS

        plt.plot(timeAxis[indexes[0]],acc1[indexes[0]],'g+',label= "Maxima Locaux")
        # ONLY 2 MAXs SELECTED
        plt.plot(timeAxis[indexes[0][maxcue]],acc1[indexes[0][maxcue]],'r+', label = " Maxima locaux")
        plt.plot(timeAxis[indexes[0][maxcue+1]],acc1[indexes[0][maxcue+1]],'r+')

        # THE PERIOD FOR THOSE SELECTED MAXs
        plt.plot([ timeAxis[indexes[0][maxcue]] ,timeAxis[indexes[0][maxcue+1]]],[0,0],'r',label=periodlabel1)
        plt.title(title1)

        plt.xlabel('temps ( en $s$)')
        plt.ylabel("$A_{1}$ ( en $m.s^{-2}$)")

        plt.grid(True)

        ### SECOND PLOT ###
        plt.subplot(212)
        # ACC2

        plt.plot(timeAxis[nstart:nstop], acc2[nstart:nstop] , '-', lw=2, label = "$A_{2}$ de l'accéleration" )
        #plt.xlim(nstart,nstop)
        # ALL MAXS
        plt.plot(timeAxis[indexes[1]],acc2[indexes[1]],'g+', label="Maxima Locaux")

        # ONLY 2 MAXs SELECTED
        plt.plot(timeAxis[indexes[1][maxcue]],acc2[indexes[1][maxcue]],'r+', label = " Maxima locaux")
        plt.plot(timeAxis[indexes[1][maxcue+1]],acc2[indexes[1][maxcue+1]],'r+')
        # THE PERIOD FOR THOSE SELECTED MAXs
        plt.plot([timeAxis[indexes[1][maxcue]],timeAxis[indexes[1][maxcue+1]]],[0,0],'r', label = periodlabel2)
        plt.title(title2)

        plt.xlabel('temps ( en $s$)')
        plt.ylabel("$A_{2}$ ( en $m.s^{-2}$)")
        plt.subplots_adjust(hspace=0.5)
        plt.legend(loc="best")
        plt.grid(True)
        ### SHOW OR SAVE ? ###
        if show==True :
            plt.show()
        if show==False :
            plt.savefig(projectPath + "exports/" + savetitle + ".png")
        return(T1,T2)
